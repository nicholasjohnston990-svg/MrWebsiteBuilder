
function calculate(){
  const t=parseInt(document.getElementById('type').value);
  const a=parseInt(document.getElementById('auto').value);
  document.getElementById('result').innerText="Estimated price: $"+(t+a);
}
